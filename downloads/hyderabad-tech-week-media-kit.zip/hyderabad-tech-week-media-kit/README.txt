Hyderabad Tech Week - Media kit
By Curious Commons

Logos: SVG masters and PNG exports; profile.png has a pure-white background.
Use the supplied artwork unchanged, with clear space of half a capital letter.
Fonts: bundled under their accompanying licences.
The guide is for digital use; obtain a printer's colour proof for physical materials.
No event dates, venues, speakers or partnerships are announced by this kit.
Logo use does not imply permission to announce an affiliation or sponsorship.
Contact: hello@curiouscommons.com
